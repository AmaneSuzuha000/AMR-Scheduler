"""Discrete-time simulation main loop.

Time model
----------
Fixed step ``dt`` seconds. Event-driven execution is not used: conflict
resolution happens on a space-time grid and must share the same discretization
as execution. Under a fixed step, identical input always yields identical
output, which is what the paired comparisons require.

Where the two planners differ
-----------------------------
The difference lives in :meth:`Simulator._plan_and_reserve`:

* **Planner A writes the whole path into the reservation table at planning
  time**, including per-step edge and node occupancy. Later vehicles can "see"
  the intentions of every vehicle ahead of them while planning.
* **Space-time A*** steers around those reservations; **static Dijkstra** does
  not and simply takes the shortest path. The static planner writes no
  reservation (it has no notion of conflict), so its paths overlap with others
  and are stopped at execution time by :meth:`Simulator._can_enter`, which
  shows up as waiting.

This is the fair comparison of "conflict resolution vs none": both use the same
executor, the same allocator, and the same instances. The only variable is
whether the planner understands space-time occupancy.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from amr_sched.allocation.base import AllocationStrategy
from amr_sched.entities import Agv, AgvState, Task, TaskStatus
from amr_sched.network import Network, NodeKind
from amr_sched.planners.base import PathPlanner
from amr_sched.reschedule import ReschedulePolicy
from amr_sched.reservation import Interval, ReservationTable


@dataclass
class Hop:
    """One movement segment."""

    src: str
    dst: str
    depart: int
    arrive: int


@dataclass
class _Job:
    """Execution state of one AGV's current transport task."""

    task_id: str
    leg: str                      # "to_pickup" | "to_dropoff"
    hops: list[Hop] = field(default_factory=list)
    idx: int = 0
    dwell_until: int = 0
    #: Target node of the current leg (pickup or drop-off point)
    goal: str = ""
    #: Exclusive upper bound of the hops index already written to the reservation table
    reserved_upto: int = 0


@dataclass
class SimulationConfig:
    dt: float = 1.0
    max_steps: int = 200_000
    planning_horizon: int = 20_000
    record_trajectory: bool = False
    seed: int = 0
    load_time: float = 5.0
    unload_time: float = 5.0
    #: Workstation **service time** in seconds: how long the workpiece keeps the
    #: workstation occupied after drop-off completes.
    #: 0 = the task is finished at drop-off (legacy behavior, equivalent to a
    #: workstation with no service time).
    #:
    #: Why model it separately
    #: -----------------------
    #: A maintenance workstation does not become free the moment material is
    #: dropped off — the workpiece is serviced there for a while. Without this,
    #: workstations stay forever idle, **workstation queueing is underestimated**,
    #: and system throughput is overestimated.
    #:
    #: Why the AGV does not wait alongside
    #: -----------------------------------
    #: In a real workshop the AGV leaves to do other work after drop-off and the
    #: workpiece stays at the workstation. Making the AGV wait turns the vehicle
    #: into an appendage of the workstation, so what gets measured is the
    #: workstation cycle rather than scheduling quality. This implementation
    #: therefore occupies the **workstation only**, never the AGV.
    process_time: float = 0.0
    #: Number of path segments **reserved ahead** at planning time. 0 reserves the
    #: entire path, which locks up the network.
    #: Measured sweep (20/50/100 tasks x 4/6 vehicles x 5 seeds, versus the static
    #: baseline): w=1 is best (+1.1% to +6.9%); w>=2 degrades sharply (+15% to
    #: +27%); w=0 (reserve everything) is worst. In other words, **over-coordination
    #: is worse than no coordination**. Note that w=1 still trails the baseline by a
    #: small margin — see the results report.
    reservation_window: int = 1
    #: Rescheduling policy for urgent tasks
    reschedule_policy: ReschedulePolicy = ReschedulePolicy.NONE
    #: Whether an idle vehicle yields its spot to an incoming loaded vehicle (deadlock prevention)
    idle_retreat: bool = True
    #: Whether to re-check node capacity against actual occupancy (strict, prone to livelock, off by default)
    strict_node_check: bool = False
    #: Dwell reservation window at a station, in steps. Renewed while dwelling, released on departure.
    node_hold_steps: int = 60
    #: Dwell window on ring aisles, in steps. Must be short, otherwise transit nodes get locked.
    aisle_hold_steps: int = 6
    #: Steps of continuous blocking before deadlock is declared and broken (0 = disabled)
    deadlock_timeout: int = 200


def _shortest_distance_static(network, a: str, b: str) -> float:
    """Static shortest **distance** between two nodes (ignores capacity and reservations)."""
    import heapq
    if a == b:
        return 0.0
    dist = {a: 0.0}
    pq = [(0.0, a)]
    seen = set()
    while pq:
        d, u = heapq.heappop(pq)
        if u in seen:
            continue
        seen.add(u)
        if u == b:
            return d
        for e in network.out_edges(u):
            nd = d + e.length
            if nd < dist.get(e.dst, float("inf")):
                dist[e.dst] = nd
                heapq.heappush(pq, (nd, e.dst))
    return dist.get(b, 0.0)


@dataclass
class StepRecord:
    """A complete snapshot of one time step, used for state monitoring and
    process visualization.

    Recording positions alone is not enough: without seeing what each vehicle is
    doing (idle / loading / blocked / parking) and how far each task has
    progressed (pending / assigned / picked / completed), there is no real
    process monitoring.
    """

    step: int
    agv_positions: dict[str, str]
    #: State name of each vehicle (idle / to_pickup / loading / to_dropoff / unloading / blocked / parking)
    agv_states: dict[str, str] = field(default_factory=dict)
    #: Task id currently executed by each vehicle (None when idle)
    agv_tasks: dict[str, str | None] = field(default_factory=dict)
    #: Counts per task state: pending / assigned / picked / completed
    task_counts: dict[str, int] = field(default_factory=dict)
    #: Number of vehicles blocked during this step
    n_blocked: int = 0
    #: Node occupancy summary: {node_id: [agv_id, ...]}.
    #: This is the contents of the **reservation table**, not where vehicles
    #: physically are. The whole mechanism of conflict resolution lives here, and
    #: a vehicle position plot cannot show who reserved a spot out from under whom.
    node_holds: dict[str, list[str]] = field(default_factory=dict)
    #: Remaining node sequence of each vehicle's **current leg** (including the
    #: destination, excluding nodes already passed).
    #:
    #: Why record it
    #: -------------
    #: Without it, the visualization side can only draw where a vehicle is, not
    #: where it intends to go. The requirement to show the scheduling process is
    #: met directly by these path lines.
    #:
    #: Scope: only the **current leg** (to pickup or to drop-off) is recorded, not
    #: the whole task. Cross-leg paths are replanned on reaching the switch point,
    #: so recording the old leg ahead of time would be meaningless.
    agv_paths: dict[str, list[str]] = field(default_factory=dict)
    #: Preemption events during this step: [(urgent_task_id, victim_agv_id, victim_task_id, already_picked)]
    preemptions: list[tuple[str, str, str, bool]] = field(default_factory=list)


@dataclass
class SimulationResult:
    tasks: list[Task]
    agvs: list[Agv]
    config: SimulationConfig
    trajectory: list[StepRecord] = field(default_factory=list)
    finished_step: int = 0
    total_wait_steps: int = 0
    blocked_steps: int = 0
    #: Number of blocking **events** (one continuous block counts once, distinct
    #: from the step count in blocked_steps). The acceptance metric asks for the
    #: **count** of conflict waits; only steps were recorded before, so it is added
    #: here.
    conflict_wait_events: int = 0
    replan_count: int = 0
    #: Planning retries (the task did not fail, this step simply found no route)
    planning_retries: int = 0
    #: Real failures: a task is voided because the execution position diverged from the plan
    hard_failures: int = 0
    collision_events: int = 0
    #: Number of times an urgent task preempted a normal one
    preemption_count: int = 0
    #: Preemption detail: [(step, urgent_task, victim_agv, victim_task, already_picked)]
    preemption_events: list[tuple[int, str, str, str, bool]] = field(
        default_factory=list)
    #: Deadlock breaks (the task is abandoned after a blocking timeout)
    deadlock_breaks: int = 0
    #: Material waste in seconds caused by preempting a loaded vehicle. Non-zero only under PREEMPT_ANY.
    material_waste_steps: float = 0.0
    #: Cumulative distance travelled by the whole fleet, in meters. Used to test the
    #: "detour" hypothesis: if a planner has a longer completion time but also a
    #: longer distance, it really is taking detours.
    total_distance: float = 0.0
    #: Cumulative **ideal** distance for the whole fleet (static shortest-path
    #: distance per leg). Detour ratio = total_distance / ideal_distance; 1.0 means
    #: not a single extra step was taken.
    ideal_distance: float = 0.0

    # ---------- Detour diagnostics (explains why a planner is slower) ----------

    def detour_ratio(self, network) -> float:
        """Detour ratio = actual distance / sum of static shortest distances.

        = 1.0 means not a single extra step; > 1.0 means the planner took a longer
        route. This is direct evidence for the hypothesis that space-time A*
        detours in order to yield.
        """
        ideal = 0.0
        for task in self.tasks:
            if task.complete_step is None:
                continue
            ideal += _shortest_distance_static(network, task.pickup, task.dropoff)
        if ideal <= 0:
            return 1.0
        return self.total_distance / ideal

    # ---------- The four acceptance metrics ----------

    def completed_tasks(self) -> list[Task]:
        return [t for t in self.tasks if t.status is TaskStatus.COMPLETED]

    def makespan_seconds(self) -> float:
        done = [t.complete_step for t in self.completed_tasks() if t.complete_step is not None]
        if not done:
            return float("nan")
        return max(done) * self.config.dt

    def on_time_rate(self) -> float:
        """Fraction of tasks with a due date that finished on time. Tasks without a due date are excluded."""
        with_due = [t for t in self.tasks if t.due_step is not None]
        if not with_due:
            return float("nan")
        on_time = [
            t for t in with_due
            if t.status is TaskStatus.COMPLETED
            and t.complete_step is not None
            and t.complete_step <= t.due_step
        ]
        return len(on_time) / len(with_due)

    def agv_utilization(self) -> float:
        if not self.agvs:
            return float("nan")
        ratios = []
        for a in self.agvs:
            total = a.busy_steps + a.idle_steps
            ratios.append(a.busy_steps / total if total > 0 else 0.0)
        return sum(ratios) / len(self.agvs)

    def conflict_wait_steps(self) -> int:
        """Total **steps** of conflict wait (accumulated duration, not event count)."""
        return self.blocked_steps

    def conflict_wait_count(self) -> int:
        """Number of conflict wait **events**.

        One continuous block counts once regardless of how many steps it lasts.
        Complementary to :meth:`conflict_wait_steps`: the count reflects how often
        a vehicle was interrupted, the step count reflects how long it waited in
        total. The same dataset can rank configurations differently under the two.
        """
        return self.conflict_wait_events

    def urgent_tasks(self) -> list[Task]:
        from amr_sched.entities import TaskPriority
        return [t for t in self.tasks if t.priority is TaskPriority.URGENT]

    def urgent_on_time_rate(self) -> float:
        """On-time rate of urgent tasks (only urgent tasks with a due date are counted)."""
        u = [t for t in self.urgent_tasks() if t.due_step is not None]
        if not u:
            return float("nan")
        ok = [
            t for t in u
            if t.status is TaskStatus.COMPLETED
            and t.complete_step is not None
            and t.complete_step <= t.due_step
        ]
        return len(ok) / len(u)

    def mean_response_steps(self, urgent_only: bool = False) -> float:
        """Response time: mean steps from task release to being taken up by an AGV."""
        pool = self.urgent_tasks() if urgent_only else self.tasks
        vals = [
            t.assigned_step - t.release_step
            for t in pool
            if t.assigned_step is not None
        ]
        return sum(vals) / len(vals) if vals else float("nan")

    def rate_against_due(self, dues: dict[str, int]) -> dict[str, float]:
        """Recompute the on-time rate against **externally supplied** due steps, for
        due-date definition sensitivity analysis.

        Why it is needed: the same schedule produces a completely different
        on-time rate under a different due-date definition. Judging whether the
        metric is valid requires re-judging the same completion times under several
        definitions **without re-running the simulation**. This changes the metric
        definition, not the results.
        """
        done = [t for t in self.tasks if t.complete_step is not None]
        if not done:
            return {"on_time_rate": float("nan"),
                    "urgent_on_time_rate": float("nan"), "evaluated": 0}
        ok = [t for t in done if t.complete_step <= dues[t.task_id]]
        urg = [t for t in done if t.is_urgent]
        urg_ok = [t for t in urg if t.complete_step <= dues[t.task_id]]
        return {
            "on_time_rate": len(ok) / len(done),
            "urgent_on_time_rate": (len(urg_ok) / len(urg)) if urg else float("nan"),
            "evaluated": len(done),
        }

    def summary(self) -> dict[str, float]:
        return {
            "tasks_total": len(self.tasks),
            "tasks_completed": len(self.completed_tasks()),
            "makespan_seconds": self.makespan_seconds(),
            "on_time_rate": self.on_time_rate(),
            "agv_utilization": self.agv_utilization(),
            "conflict_wait_steps": self.conflict_wait_steps(),
            "conflict_wait_events": self.conflict_wait_count(),
            "planner_reported_wait": self.total_wait_steps,
            "replan_count": self.replan_count,
            "planning_retries": self.planning_retries,
            "hard_failures": self.hard_failures,
            "collision_events": self.collision_events,
            "urgent_on_time_rate": self.urgent_on_time_rate(),
            "mean_response_steps": self.mean_response_steps(),
            "mean_urgent_response_steps": self.mean_response_steps(urgent_only=True),
            "preemption_count": self.preemption_count,
            "deadlock_breaks": self.deadlock_breaks,
            "material_waste_steps": self.material_waste_steps,
            "finished_step": self.finished_step,
        }


class Simulator:
    """Wire up network, tasks, AGVs, planner, and allocator, then run one full simulation."""

    def __init__(
        self,
        network: Network,
        tasks: list[Task],
        agvs: list[Agv],
        planner: PathPlanner,
        allocator: AllocationStrategy,
        config: SimulationConfig | None = None,
    ) -> None:
        self.network = network
        self.tasks = tasks
        self.agvs = agvs
        self.planner = planner
        self.allocator = allocator
        self.config = config or SimulationConfig()

        self._res = ReservationTable()
        self._task_by_id = {t.task_id: t for t in tasks}
        self._travel_cache: dict[tuple[str, str], float] = {}
        self._jobs: dict[str, _Job] = {}
        self._transit: dict[str, tuple[str, str, int, int]] = {}

        self._total_wait = 0
        self._blocked = 0
        self._replans = 0
        self._planning_retries = 0
        self._hard_failures = 0
        self._collisions = 0
        self._preemptions = 0
        self._preemption_events: list[tuple[int, str, str, str, bool]] = []
        self._step_preemptions: list[tuple[str, str, str, bool]] = []
        #: Dwell reservation per vehicle at its destination node (node, Interval), released on departure
        self._node_hold: dict[str, tuple[str, Interval]] = {}
        #: Arrival reservation for in-transit vehicles (node, Interval), released on arrival
        self._node_claim: dict[str, tuple[str, Interval]] = {}
        #: First step of each vehicle's current continuous block (for deadlock timeout)
        self._blocked_since: dict[str, int] = {}
        self._conflict_wait_events: int = 0
        # Distance accumulation (extra metric + detour diagnostics)
        self._odometer = 0.0
        # Material waste from preempting loaded vehicles, in seconds. Accumulated only under PREEMPT_ANY.
        self._material_waste_steps = 0.0
        self._ideal_odometer = 0.0
        self._deadlock_breaks = 0
        self._trajectory: list[StepRecord] = []
        #: Step cursor. Initialized at construction so external reads before reset() do not fail.
        self._step_cursor = 0

    # ---------- Helpers ----------

    def _max_speed(self) -> float:
        return getattr(self.planner, "max_speed", 1.0)

    def _hop_steps(self, src: str, dst: str) -> int:
        return self.planner.steps_for(
            self.network.edge(src, dst).traversal_time(self._max_speed())
        )

    def _load_steps(self, task: "Task | None" = None) -> int:
        """Load duration in steps. Uses the per-material value when material typing
        is on, otherwise a global constant.

        Three material types are specified: bogie, wheelset, and brake valve. Their
        weight and handling difficulty differ by an order of magnitude.
        With ``material_mix=False`` (the default) behavior matches historical data
        exactly; when enabled, :meth:`MaterialType.typical_load_steps` decides.
        """
        mt = getattr(task, "material_type", None) if task is not None else None
        if mt is not None:
            return max(1, int(mt.typical_load_steps()))
        return max(1, int(math.ceil(self.config.load_time / self.config.dt)))

    def _unload_steps(self, task: "Task | None" = None) -> int:
        """Unload duration in steps. Same rules as :meth:`_load_steps`."""
        mt = getattr(task, "material_type", None) if task is not None else None
        if mt is not None:
            # Unloading is one notch faster than loading: no spreader alignment is
            # needed, the load simply drops into place
            return max(1, int(math.ceil(mt.typical_load_steps() * 0.6)))
        return max(1, int(math.ceil(self.config.unload_time / self.config.dt)))

    def _has_processing(self, node_id: str) -> bool:
        """Whether this node has a processing operation.

        Only **workstations** and **assembly areas** perform processing; buffers are
        transit staging, where a load is dropped off and leaves immediately.
        Adding processing time to buffers as well would turn each buffer into a
        second workstation, which makes no physical sense.
        """
        kind = self.network.node(node_id).kind
        return kind in (NodeKind.WORKSTATION, NodeKind.ASSEMBLY)

    def _process_steps(self) -> int:
        """Workstation processing time converted to steps. 0 means not modelled and returns 0 (not 1)."""
        if self.config.process_time <= 0:
            return 0
        return max(1, int(math.ceil(self.config.process_time / self.config.dt)))

    # ---------- Plan and reserve ----------

    def _plan_and_reserve(
        self, agv: Agv, src: str, goal: str, start_step: int, reserve: bool
    ) -> tuple[list[Hop], int, int] | None:
        """Plan one leg; with ``reserve=True`` the first N hops are written into the reservation table.

        Returns ``(hops, end step, number of hops reserved)``.
        

        The static planner (``reservations_aware = False``) writes no reservations —
        it is inherently "blind" to the others, and precisely that is what defines
        it as the baseline.
        """
        if src == goal:
            # The vehicle already stands on the goal: no movement is needed.
            # Three elements must be returned to match the caller's unpacking (this
            # used to be a bug source: once "zero distance must record 0" was fixed,
            # this branch was taken for the first time and the defect surfaced at once).
            return [], start_step, 0

        path = self.planner.plan(
            network=self.network,
            start=src,
            goal=goal,
            start_step=start_step,
            reservations=self._res,
            agv_id=agv.agv_id,
            horizon=min(start_step + self.config.planning_horizon, self.config.max_steps),
        )
        if path is None:
            return None
        self._total_wait += path.wait_steps
        # The plan must fall inside the simulation horizon.
        #
        # Under heavy congestion the planner emits plans that "depart only after a
        # long wait", whose arrival step may **exceed max_steps**. Once such a plan
        # is committed, the vehicle enters ``_transit`` and waits for an arrival
        # step that never comes — the simulation then never finishes even after
        # running to the horizon (measured with a 450 s processing time: AGV00 got
        # stuck at arrive=200021 > max_steps=200000 and was blocked for 100k steps).
        # Reject it here up front and leave the vehicle in place to replan next step.
        if path.arrival_steps and path.arrival_steps[-1] >= self.config.max_steps:
            return None

        hops: list[Hop] = []
        cur = src
        t = start_step
        for node, arrive in zip(path.nodes, path.arrival_steps):
            if node == cur:
                continue
            hops.append(Hop(cur, node, t, arrive))
            cur = node
            t = arrive

        if reserve:
            win = self.config.reservation_window
            upto = len(hops) if win <= 0 else min(len(hops), win)
            for h in hops[:upto]:
                self._reserve_hop(agv, h)
            return hops, t, upto
        return hops, t, 0

    def _reserve_hop(self, agv: Agv, hop: Hop) -> None:
        """Write one movement segment into the reservation table (both directions are
        taken, modelling a single-lane aisle)."""
        self._res.reserve_edge(hop.src, hop.dst, Interval(hop.depart, hop.arrive), agv.agv_id)
        if self.network.has_edge(hop.dst, hop.src):
            self._res.reserve_edge(hop.dst, hop.src, Interval(hop.depart, hop.arrive), agv.agv_id)
        self._res.reserve_node(
            hop.dst, Interval(hop.arrive, hop.arrive + 1), agv.agv_id
        )

    def _extend_reservations(self, agv: Agv, job: _Job, now: int) -> None:
        """Rolling top-up: write the following hops inside the window into the
        reservation table, with their times re-laid out from the current progress."""
        # The static baseline takes no part in the reservation system: it neither
        # reads nor writes reservations.
        if not getattr(self.planner, "reservations_aware", False):
            return
        win = self.config.reservation_window
        if win <= 0:
            return
        target = min(len(job.hops), job.idx + win)
        if target <= job.reserved_upto:
            return
        # Re-lay out the times of the following hops starting from the current actual time
        tt = now
        for h in job.hops[job.idx:target]:
            n = self._hop_steps(h.src, h.dst)
            h.depart = max(h.depart, tt)
            h.arrive = h.depart + n
            self._reserve_hop(agv, h)
            tt = h.arrive
        job.reserved_upto = target

    def _refresh_node_holds(self, step: int) -> None:
        """Refresh the "dwell reservation": wherever a vehicle stands, it holds that node
        until it leaves.

        Why this is mandatory
        ---------------------
        Reserving only the "edges" is not enough: after arriving, a vehicle loads,
        unloads and waits for its next task, and throughout that time it
        **physically stands on the node**. Without holding the node, other vehicles
        see it as free in the reservation table and drive in — measured to cause
        hundreds of node capacity violations (two vehicles overlapping on the same
        workstation).

        Implementation notes
        --------------------
        * Each step **first releases** the previous dwell reservation unconditionally,
          so a vehicle that has driven away does not keep holding the old node (leak);
        * then the node is reserved again as ``[step, step+HOLD)`` if the vehicle is
          currently standing on it;
        * HOLD is a finite value, so even if the logic is wrong it expires by itself
          and never locks the network up forever.
        """
        hold = self.config.node_hold_steps
        for agv in self.agvs:
            prev = self._node_hold.pop(agv.agv_id, None)
            if prev is not None:
                self._res.release_node(prev[0], prev[1], agv.agv_id)
            # Only vehicles that have **already arrived** may release their arrival
            # claim; a vehicle still en route must keep holding its target node,
            # otherwise the following vehicle assumes the slot is free.
            if agv.agv_id not in self._transit:
                claim = self._node_claim.pop(agv.agv_id, None)
                if claim is not None:
                    self._res.release_node(claim[0], claim[1], agv.agv_id)
            if agv.agv_id in self._transit:
                continue
            node = agv.cur_node
            if node is None:
                continue
            # A station (workstation/buffer) gets a long dwell: the vehicle loads,
            # unloads and waits for its next task here;
            # a ring aisle gets only a **short window**: the vehicle is just passing
            # through, and holding it too long deadlocks the whole network
            # (measured: with a long dwell window on aisles too, 50/6 and 100/6 got
            # stuck at 500k steps).
            kind = self.network.node(node).kind
            if kind is NodeKind.AISLE:
                # A short dwell is enough for "I am still here at this step" to be
                # visible, without locking a transit node into a parking lot.
                span = self.config.aisle_hold_steps
            else:
                span = hold
            iv = Interval(step, step + span)
            self._res.reserve_node(node, iv, agv.agv_id)
            self._node_hold[agv.agv_id] = (node, iv)

    def _can_enter(self, agv: Agv, src: str, dst: str, t: int,
                   dwell: int = 1) -> bool:
        n = self._hop_steps(src, dst)
        arrive = t + n
        # Never step outside the simulation horizon.
        #
        # ``_plan_and_reserve`` performs the same check, but it uses the start_step
        # of the **planning instant**; a blocked vehicle actually departs at a later
        # step, and ``_commit_move`` recomputes the arrival from the actual step,
        # which can cross the horizon. Measured on the hub layout with 100 tasks /
        # 6 vehicles: arrive=119980 at planning time was legal, but in reality it
        # was 120072 > 120000, hitting the fallback assertion in ``_commit_move``
        # head-on.
        #
        # Stopping the vehicle at the boundary is right: it could not finish this
        # segment anyway, and waiting on would only conjure extra movement into the
        # statistics after the horizon.
        if arrive >= self.config.max_steps:
            return False
        edge_cap = self.network.edge(src, dst).capacity
        if self.network.has_edge(dst, src):
            edge_cap = min(edge_cap, self.network.edge(dst, src).capacity)
        occ = set(self._res.edge_conflicts(src, dst, Interval(t, arrive), exclude_agv=agv.agv_id))
        if self.network.has_edge(dst, src):
            occ |= set(self._res.edge_conflicts(dst, src, Interval(t, arrive), exclude_agv=agv.agv_id))
        if len(occ) >= edge_cap:
            return False
        # The destination node must be free across the whole **dwell window**, not
        # just at the arrival step. This is the key to fixing "two vehicles parked on
        # the same workstation": the vehicle loads/unloads after arriving, and that
        # time also occupies node capacity.
        if not self._res.is_node_free(
            dst, Interval(arrive, arrive + max(1, dwell)),
            self.network.node(dst).capacity, exclude_agv=agv.agv_id
        ):
            return False
        # Workstation processing occupancy: while the workpiece is still at the
        # workstation, no other vehicle may drive in.
        # Note that this uses the **arrive instant**, not the whole dwell window —
        # processing routinely ends after arrival, and requiring the entire dwell
        # window to be free would produce "processing not finished yet + I can stop
        # but not fit", an over-conservative decision.
        if self._process_holds.get(dst):
            live = [h for h in self._process_holds[dst] if h[1] > arrive]
            if live:
                # Drop expired records so the list does not grow without bound
                self._process_holds[dst] = live
                if len(live) >= self.network.node(dst).capacity:
                    return False
        # Optional fallback: check once more against "the number of vehicles actually
        # standing on the node".
        # Note: this check makes two vehicles see each other and both stand still,
        # which easily causes **livelock** under high load, so it is off by default
        # and enabled only when strict verification is needed.
        if self.config.strict_node_check:
            here = [
                a for a in self.agvs
                if a.agv_id != agv.agv_id
                and a.agv_id not in self._transit
                and a.cur_node == dst
            ]
            if len(here) >= self.network.node(dst).capacity:
                return False
        return True

    def _commit_move(self, agv: Agv, src: str, dst: str, t: int,
                     dwell: int = 1) -> None:
        n = self._hop_steps(src, dst)
        arrive = t + n
        self._res.reserve_edge(src, dst, Interval(t, arrive), agv.agv_id)
        if self.network.has_edge(dst, src):
            self._res.reserve_edge(dst, src, Interval(t, arrive), agv.agv_id)
        # Key point: claim the **destination node** already at commit time, otherwise
        # two vehicles can both pass the admission check at the same instant and both
        # drive toward the same capacity-1 workstation (measured close to a hundred
        # overlaps). It is released on arrival and taken over by the dwell reservation
        # in ``_refresh_node_holds``.
        claim = Interval(arrive, arrive + max(1, dwell))
        self._res.reserve_node(dst, claim, agv.agv_id)
        self._node_claim[agv.agv_id] = (dst, claim)
        if arrive > self.config.max_steps:
            # The last gate: never allow a commit to an instant that cannot be
            # reached. Reaching this point means an upstream check was missed; raise
            # rather than hang silently.
            raise RuntimeError(
                "commit_move arrival step %d exceeds max_steps %d (%s: %s->%s)"
                % (arrive, self.config.max_steps, agv.agv_id, src, dst))
        # (src, dst, depart, arrive): depart is kept so consumers can interpolate a
        # continuous position along the edge instead of snapping to an endpoint.
        self._transit[agv.agv_id] = (src, dst, t, arrive)
        # Odometer accumulation: the length of the edge actually travelled.
        # Compared with "the static shortest-path distance from task origin to
        # destination", it reveals how much of a detour the planner took.
        self._odometer += self.network.edge(src, dst).length

    # ---------- Allocation ----------

    def _try_assign(self, agv: Agv, task: Task, t: int) -> bool:
        here = agv.cur_node or agv.start_node
        reserve = getattr(self.planner, "reservations_aware", False)

        # Plan **only the first leg**. The second leg is planned after reaching the
        # pickup point: reserving both legs at once locks up the whole network for a
        # long time, which was measured to make space-time A* worse than the baseline.
        leg1 = self._plan_and_reserve(agv, here, task.pickup, t, reserve)
        if leg1 is None:
            return False
        hops1, t_pick, upto = leg1

        self._jobs[agv.agv_id] = _Job(
            task_id=task.task_id, leg="to_pickup", hops=hops1,
            goal=task.pickup, reserved_upto=upto,
        )
        self._load_end[agv.agv_id] = t_pick + self._load_steps(self._task_by_id.get(agv.cur_task))

        agv.cur_task = task.task_id
        agv.state = AgvState.TO_PICKUP
        task.status = TaskStatus.ASSIGNED
        task.assigned_agv = agv.agv_id
        task.assigned_step = t
        return True

    # ---------- Main loop ----------

    # ---- Step-by-step execution interface (added in an earlier round, round 64,
    # ---- to let the Web console drive the simulation live) ----
    #
    # Motivation for the split: ``run()`` is an uninterruptible for loop, so the Web
    # side cannot show a run in progress and can only wait for it to finish and then
    # look at the results — exactly the "live run vs. result replay" gap the advisor
    # pointed out.
    #
    # Principle of the split: **bit-for-bit equivalence**. ``reset()`` plus repeated
    # calls to ``step_once()`` must produce exactly the same SimulationResult as
    # ``run()``.
    # This is asserted by tests/test_simulator_stepping.py (including a SHA comparison).

    def reset(self) -> None:
        """Restore the simulator to the "not started" state; may be called repeatedly.

        Why the reset must be exhaustive
        --------------------------------
        The Web console allows "rerun with the same configuration". If ``reset()``
        misses resetting any single item, the second run carries leftovers from the
        first — most typically tasks already marked COMPLETED, so the second run
        reports "all done" right after starting and looks like it finished in 0
        steps. Such a defect throws no exception; it only yields silently wrong
        results.

        An earlier round (round 64) filled in the 8 state items that had been
        missed: task status, reservation table, job table, transit table, node
        occupancy, the various counters, the event list, and the trajectory.
        ``test_reset_is_idempotent`` locks this invariant down.
        """
        self._load_end: dict[str, int] = {}
        self._drop_arrive: dict[str, int] = {}
        #: Workstation processing occupancy: node_id -> (start step, end step, agv_id)
        self._process_holds: dict[str, list[tuple[int, int, str]]] = {}
        self._drop_end: dict[str, int] = {}
        self._step_cursor = 0

        # --- The items missed before an earlier round (round 64) filled them in ---
        for task in self.tasks:
            task.status = TaskStatus.PENDING
            task.assigned_agv = None
            task.assigned_step = None
            task.pickup_step = None
            task.complete_step = None
        self._res = ReservationTable()
        self._jobs.clear()
        self._transit.clear()
        self._node_hold.clear()
        self._node_claim.clear()
        self._blocked_since.clear()
        self._trajectory.clear()
        self._preemption_events.clear()
        self._step_preemptions.clear()
        self._total_wait = 0
        self._blocked = 0
        self._replans = 0
        self._planning_retries = 0
        self._hard_failures = 0
        self._collisions = 0
        self._preemptions = 0
        self._conflict_wait_events = 0
        self._odometer = 0.0
        self._ideal_odometer = 0.0
        self._material_waste_steps = 0.0
        self._deadlock_breaks = 0

        for agv in self.agvs:
            agv.cur_node = agv.start_node
            agv.cur_task = None
            agv.state = AgvState.IDLE
            agv.route = []
            agv.depart_step = None
            agv.reset_stats()

    def step_once(self) -> bool:
        """Advance one simulation step. Returns True if it should continue, False if
        it has terminated.

        The termination conditions correspond one to one with the loop condition of
        ``run()``:
        (1) all tasks are completed/failed; (2) ``max_steps`` is reached.
        """
        cfg = self.config
        step = self._step_cursor
        # Step-by-step driving (Web console / Demo B live channel) must reset() first.
        #
        # run() calls reset() itself, but an external direct call to step_once() does
        # not, and the state tables _load_end / _drop_arrive / _drop_end are only
        # created inside reset().
        # If that is missed, the first task assignment raises AttributeError:
        # '_load_end', with the error sighted several layers away from the real
        # cause, which is very hard to trace.
        #
        # Check explicitly here and put the reason into the exception, instead of
        # letting it surface as an AttributeError.
        if not hasattr(self, "_load_end"):
            raise RuntimeError(
                "reset() must be called before step_once(): "
                "the state tables _load_end/_drop_arrive/_drop_end are created by reset()."
                " (run() calls reset() internally; a step-by-step driver must call it itself.)"
            )
        if step >= cfg.max_steps:
            return False
        if self._all_done():
            return False
        self._occupancy_check()
        self._reschedule_step(step)
        self._break_deadlock(step)
        self._park_step(step)
        self._assign_step(step)
        self._refresh_node_holds(step)
        self._advance_step(step)
        self._record(step)
        if step % 500 == 0 and step > 0:
            self._res.purge_before(step)
        self._step_cursor = step + 1
        return True

    def is_finished(self) -> bool:
        """Whether the termination condition is already met (without advancing state)."""
        return self._all_done() or self._step_cursor >= self.config.max_steps

    def run(self) -> SimulationResult:
        cfg = self.config
        self.reset()
        while self.step_once():
            pass
        step = self._step_cursor
        return self._build_result(step)

    def _build_result(self, step: int | None = None) -> SimulationResult:
        """Assemble the current state into a SimulationResult.

        Extracted so that the step-by-step driver can also produce exactly the same
        object as ``run()``, instead of writing the assembly logic twice and letting
        the two drift apart over time.
        """
        if step is None:
            step = self._step_cursor
        cfg = self.config
        return SimulationResult(
            tasks=self.tasks, agvs=self.agvs, config=cfg, trajectory=self._trajectory,
            finished_step=step, total_wait_steps=self._total_wait,
            blocked_steps=self._blocked, replan_count=self._replans,
            conflict_wait_events=self._conflict_wait_events,
            planning_retries=self._planning_retries,
            hard_failures=self._hard_failures,
            collision_events=self._collisions,
            preemption_count=self._preemptions,
        preemption_events=list(self._preemption_events),
            deadlock_breaks=self._deadlock_breaks,
            material_waste_steps=self._material_waste_steps,
        )



    def _all_done(self) -> bool:
        return all(t.status in (TaskStatus.COMPLETED, TaskStatus.FAILED) for t in self.tasks)

    def _occupancy_check(self) -> None:
        seen: dict[str, list[str]] = {}
        for agv in self.agvs:
            if agv.agv_id in self._transit:
                continue
            if agv.cur_node is None:
                continue
            seen.setdefault(agv.cur_node, []).append(agv.agv_id)
        for node, ids in seen.items():
            cap = self.network.node(node).capacity
            if len(ids) > cap:
                self._collisions += len(ids) - cap

    def _break_deadlock(self, step: int) -> None:
        """Deadlock breaking: a vehicle blocked for too long abandons its current task,
        returns it to the queue and gives up its spot.

        Why it is needed
        ----------------
        Once node capacity is enforced strictly, a ring network under high load
        develops **circular waiting** (A waits for B, B for C, C for A). Measured
        without breaking, 2 tasks at 50/6 and 2 tasks at 100/6 never finish, and the
        simulation runs all the way to max_steps.

        Breaking rules
        --------------
        When a vehicle has been continuously blocked for more than
        ``deadlock_timeout`` steps, it is made to:
        1. **return its current task to the pending queue** (the task is not lost; it
           is reassigned later);
        2. release every reservation it holds;
        3. become idle, leaving the scheduler to decide the next move.

        With one fewer competitor in the cycle the other vehicles can move on. In a
        real AGV system, this mechanism corresponds to "the scheduler steps in and
        resolves the deadlock".
        """
        timeout = self.config.deadlock_timeout
        if timeout <= 0:
            return
        for agv in self.agvs:
            since = self._blocked_since.get(agv.agv_id)
            if since is None or step - since < timeout:
                continue
            job = self._jobs.pop(agv.agv_id, None)
            if job is None:
                self._blocked_since.pop(agv.agv_id, None)
                continue
            task = self._task_by_id.get(job.task_id)
            # A picked task **must not** be returned to pending assignment:
            #
            # The load is already on the vehicle; returning it to PENDING makes the
            # next vehicle (or the same one) go to the pickup point and pick it up
            # once more — that does not exist physically, and logically it turns into
            # a livelock: measured, AGV00 holding T0001 (picked, load on board) was
            # broken, the task fell back to PENDING, the vehicle returned to R1, was
            # assigned T0001 again, was told to go back to D for pickup, and never
            # finished — stuck for 100k steps.
            #
            # Correct handling: let this vehicle deliver the load first. Breaking the
            # deadlock only releases the "claim"; it does not change task ownership;
            # if the vehicle really cannot move, later rounds step in again.
            # Picked task: the load is on board, so it **must not** simply be returned
            # to PENDING.
            #
            # Returning it to PENDING directly would make the next assignment send some
            # vehicle back to the original pickup point to pick it up again — but the
            # load is no longer there. Measured, this path made AGV00 loop
            # "go to D for pickup -> back to R1 -> broken again -> go to D again" and
            # get stuck for 100k steps.
            #
            # Correct approach: **move the pickup point to the vehicle's current
            # position**. The physical meaning is "the load is already on this vehicle,
            # located here", and the task continues with the next vehicle from here.
            # This drops the lock without inventing a second pickup.
            if task is not None and task.status is TaskStatus.PICKED:
                task.pickup = agv.cur_node or task.pickup
                task.status = TaskStatus.PENDING
                task.assigned_agv = None
                task.assigned_step = None
                task.pickup_step = None
            if task is not None and task.status is TaskStatus.ASSIGNED:
                task.status = TaskStatus.PENDING
                task.assigned_agv = None
                task.assigned_step = None
                task.pickup_step = None
            agv.cur_task = None
            agv.state = AgvState.IDLE
            for d in (self._load_end, self._drop_end, self._node_hold,
                      self._node_claim, self._transit):
                d.pop(agv.agv_id, None)
            self._res.release_all(agv.agv_id)
            self._blocked_since.pop(agv.agv_id, None)
            self._deadlock_breaks += 1

    def _park_step(self, step: int) -> None:
        """Idle vehicles yield: they must not occupy "the node someone else is heading
        for".

        Why it is needed
        ----------------
        Station capacity is limited (workstation 1, buffer 2). If an empty vehicle
        just stays where it unloaded, the next loaded vehicle coming to deliver can
        never get in — measured, 2 loaded vehicles were each blocked for 170k steps
        and the whole simulation ran to max_steps without finishing.

        Yielding rules
        --------------
        If the node an idle vehicle stands on is **the destination of any in-transit
        task**, move it to the nearest buffer/aisle slot that is unused and not
        claimed by any task.
        """
        if not self.config.idle_retreat:
            return

        # Destinations of all in-transit tasks — these nodes must stay clear
        wanted: set[str] = set()
        for agv in self.agvs:
            job = self._jobs.get(agv.agv_id)
            if job is not None and job.goal:
                wanted.add(job.goal)
        if not wanted:
            return

        # Waypoints must yield too (fixed in an earlier round, round 65).
        #
        # The original rule looked only at "destinations" and missed choke points.
        # Measured (50 tasks / 4 vehicles / capacity 1 / seed 1): AGV00 stopped on R5
        # after unloading and stayed put, and R5 is the only entrance to W5 (the only
        # incoming edge of W5 is R5->W5). The other three vehicles all had to pass
        # through R5 to reach W5 and were all blocked — AGV00 held R5 for 117337 steps
        # (about 32 hours), deadlock_breaks reached 2501, and only 48/50 tasks
        # completed.
        #
        # A vehicle not occupying a critical node "legitimately" squatted on the choke
        # point because its own destination was in nobody's target set — yet other
        # vehicles' **waypoints** included it.
        # So the remaining path nodes of in-transit vehicles must also be added to the
        # set that has to stay clear.
        #
        # Blast radius: only extreme configurations with aisle_capacity=1 are affected;
        # instances with capacity>=2 are bit-for-bit unchanged (verified with 10 paired
        # runs).
        for agv in self.agvs:
            job = self._jobs.get(agv.agv_id)
            if job is None or not job.hops:
                continue
            for k in range(job.idx, len(job.hops)):
                wanted.add(job.hops[k].dst)

        for agv in self.agvs:
            if agv.agv_id in self._jobs or agv.agv_id in self._transit:
                continue
            node = agv.cur_node or agv.start_node
            if node not in wanted:
                continue
            target = self._nearest_park(node, avoid=wanted)
            if target is None:
                continue
            planned = self._plan_and_reserve(
                agv, node, target, step,
                getattr(self.planner, "reservations_aware", False),
            )
            if planned is None:
                continue
            hops, _t_arr, upto = planned
            self._jobs[agv.agv_id] = _Job(
                task_id=None, leg="park", hops=hops,
                goal=target, reserved_upto=upto,
            )
            agv.state = AgvState.PARKING

    def _nearest_park(self, from_node: str,
                      avoid: set[str] | None = None) -> str | None:
        """Find the nearest buffer/aisle node that has spare capacity and is not claimed
        by anyone else."""
        avoid = avoid or set()
        best: tuple[float, str] | None = None
        for n in self.network.nodes.values():
            if n.node_id == from_node:
                continue
            if n.kind not in (NodeKind.BUFFER, NodeKind.AISLE):
                continue
            if n.node_id in avoid:
                continue
            occ = sum(
                1 for a in self.agvs
                if a.agv_id not in self._transit and a.cur_node == n.node_id
            )
            if occ >= n.capacity:
                continue
            tt = self._travel_time(from_node, n.node_id)
            if tt == float("inf"):
                continue
            if best is None or tt < best[0]:
                best = (tt, n.node_id)
        return best[1] if best else None

    def _reschedule_step(self, step: int) -> None:
        """Dynamic rescheduling when an urgent task arrives (the task specification R2.5).

        Triggered only on **newly issued** urgent tasks, so preemption is not repeated
        every step.
        """
        if self.config.reschedule_policy is ReschedulePolicy.NONE:
            return

        # Find the urgent tasks that arrived this step and are not yet assigned
        urgent_waiting = [
            t for t in self.tasks
            if t.release_step == step
            and t.is_urgent
            and t.status is TaskStatus.PENDING
        ]
        if not urgent_waiting:
            return

        for urgent in urgent_waiting:
            victim = self._pick_preemption_victim(step, urgent)
            if victim is None:
                return
            was_picked = (urgent is not None)  # placeholder, recomputed below
            victim_task = victim.cur_task
            victim_picked = False
            if victim_task is not None:
                vt = self._task_by_id.get(victim_task)
                if vt is not None:
                    victim_picked = (vt.status is TaskStatus.PICKED)
            if self._cancel_job(victim):
                self._preemptions += 1
                self._preemption_events.append(
                    (step, urgent.task_id, victim.agv_id,
                     victim_task or "", victim_picked))
                self._step_preemptions.append(
                    (urgent.task_id, victim.agv_id,
                     victim_task or "", victim_picked))

    def _pick_preemption_victim(self, step: int, urgent: Task) -> Agv | None:
        """Pick the AGV most worth preempting.

        Selection criteria (in priority order):
        1. the vehicle that can **reach the urgent pickup point fastest** — this is
           the essential requirement of urgency;
        2. under equal conditions, the one with the **least empty-running waste**
           (more remaining hops = it has not gone far yet).

        Restrictions:
        * only preempt vehicles that are "running empty toward a pickup and not yet
          loaded" (zero material cost);
        * never preempt another urgent task.

        On in-transit vehicles (fixed in an earlier round, round 37)
        ------------------------------------------------------------
        There used to be a line ``if agv.agv_id in self._transit: continue`` here,
        with the comment "cannot reroute on an edge". That restriction **made the
        preemption mechanism almost useless**: measured, when an urgent task is issued
        an average of **3.15 of 4 vehicles are travelling on an edge**, and half of the
        remaining 0.85 are idle vehicles. As a result, **47% of ``PREEMPT_UNPICKED``
        runs recorded zero preemptions.

        But that restriction is not technically necessary: ``_cancel_job`` already
        clears ``_transit`` and all reservations, and which end of the edge the vehicle
        rests on is determined by ``cur_node``.
        After cancellation the vehicle simply replans from its current position, which is
        entirely reasonable physically — a real AGV receiving a reassignment instruction
        in the middle of an aisle also pulls over to the nearest stop and turns around.

        So the restriction is lifted: **in-transit vehicles are equally preemptable**,
        taking the ``cur_node`` where the vehicle currently is.
        """
        best: Agv | None = None
        best_key: tuple[float, int] = (float("inf"), 0)

        for agv in self.agvs:
            job = self._jobs.get(agv.agv_id)
            if job is None:
                continue
            # Not picked yet (to_pickup): preemptable under any policy;
            # loaded (to_dropoff): only PREEMPT_ANY preempts — that setting exists
            # specifically to quantify the material cost of "preempting a loaded
            # vehicle".
            if job.leg == "to_dropoff":
                if self.config.reschedule_policy is not ReschedulePolicy.PREEMPT_ANY:
                    continue
            elif job.leg != "to_pickup":
                continue
            task = self._task_by_id.get(job.task_id)
            if task is None or task.is_urgent:
                continue
            here = agv.cur_node or agv.start_node
            eta = self._travel_time(here, urgent.pickup)
            if eta == float("inf"):
                continue
            remaining = len(job.hops) - job.idx   # the more, the less far it has gone and the smaller the waste
            key = (eta, -remaining)
            if key < best_key:
                best_key = key
                best = agv
        return best

    def _travel_time(self, a: str, b: str) -> float:
        """Cached static shortest travel time (in seconds)."""
        if a == b:
            return 0.0
        key = (a, b)
        if key not in self._travel_cache:
            d = self.network.shortest_travel_times(a, self._max_speed())
            for k, v in d.items():
                self._travel_cache[(a, k)] = v
            self._travel_cache[key] = d.get(b, float("inf"))
        return self._travel_cache[key]

    def _cancel_job(self, agv: Agv) -> bool:
        """Cancel the AGV's current task; the task returns to pending assignment.

        Two cases:
        * ``to_pickup`` (not picked): zero material cost, allowed under any
          preemption policy;
        * ``to_dropoff`` (loaded): **has a material cost** — the load is already on
          board and after preemption must be carried back to the pickup point and
          queued again. Allowed only under ``PREEMPT_ANY``, and the travel time of
          that return trip is charged to ``_material_waste_steps``.
        """
        job = self._jobs.get(agv.agv_id)
        if job is None:
            return False
        task = self._task_by_id[job.task_id]

        if job.leg == "to_dropoff":
            if self.config.reschedule_policy is not ReschedulePolicy.PREEMPT_ANY:
                return False
            if task.is_urgent:
                return False
            # Material cost = the pickup leg already travelled + taking it back to the
            # pickup point from the current position.
            # The first term is "distance already run for nothing", the second is
            # "distance still to be run for nothing", and only their sum is the
            # transport capacity this preemption really wastes.
            here = agv.cur_node or agv.start_node
            back = self._travel_time(here, task.pickup)
            if back == float("inf"):
                back = 0.0
            # job.idx is the number of hops already travelled; prorate the pickup-leg
            # travel time by the travelled fraction
            full = self._travel_time(task.pickup, task.dropoff)
            walked = 0.0
            for k in range(min(job.idx, len(job.hops))):
                walked += self.network.edge(job.hops[k].src,
                                           job.hops[k].dst).length / max(1e-9, self._max_speed())
            self._material_waste_steps += walked + back
        elif job.leg != "to_pickup":
            return False
        elif task.status is not TaskStatus.ASSIGNED:
            return False

        task.status = TaskStatus.PENDING
        task.assigned_agv = None
        task.assigned_step = None
        task.pickup_step = None
        agv.cur_task = None
        agv.state = AgvState.IDLE
        self._jobs.pop(agv.agv_id, None)
        self._load_end.pop(agv.agv_id, None)
        self._drop_end.pop(agv.agv_id, None)
        self._node_hold.pop(agv.agv_id, None)
        self._node_claim.pop(agv.agv_id, None)
        self._transit.pop(agv.agv_id, None)
        self._res.release_all(agv.agv_id)
        return True

    def _assign_step(self, step: int) -> None:
        idle = [a for a in self.agvs if a.cur_task is None and a.agv_id not in self._transit]
        if not idle:
            return
        pending = [
            t for t in self.tasks
            if t.status is TaskStatus.PENDING and t.release_step <= step
        ]
        if not pending:
            return
        pairs = self.allocator.allocate(
            self.network, idle, pending, step, self._max_speed(), self._travel_cache
        )
        for agv, task in pairs:
            if not self._try_assign(agv, task, step):
                # No feasible path can be planned this step; the task stays PENDING
                # and is retried next step.
                # This is a **retry counter**, not a task failure.
                self._planning_retries += 1

    def _advance_step(self, step: int) -> None:
        for agv in self.agvs:
            # 1) In transit
            tr = self._transit.get(agv.agv_id)
            if tr is not None:
                src, dst, _depart, arrive = tr
                agv.busy_steps += 1
                if step + 1 >= arrive:
                    # Hard guarantee: verify once more against the **actual occupancy**
                    # before really entering the node. The reservation table can have
                    # blind spots due to concurrent subscription/cleanup, and this is
                    # the last gate.
                    occ = sum(
                        1 for b in self.agvs
                        if b.agv_id != agv.agv_id
                        and b.agv_id not in self._transit
                        and b.cur_node == dst
                    )
                    if occ >= self.network.node(dst).capacity:
                        # Target full: wait one more step on the edge and do not
                        # complete this transfer.
                        #
                        # This **must** also be counted as blocking: the deadlock on a
                        # single-lane ring network is stuck exactly on this branch (the
                        # vehicle has reached the target edge, but the target node is
                        # held by another vehicle). If blocking were only recorded on
                        # the "no path can be planned" branch, _break_deadlock would
                        # never see a timeout, and the task would hang forever
                        # (measured breaks=0, only 48 of 50 tasks completed).
                        agv.busy_steps += 1
                        agv.blocked_steps += 1
                        agv.state = AgvState.BLOCKED
                        if agv.agv_id not in self._blocked_since:
                            # A new blocking episode starts (it was not blocked before):
                            # count 1 event
                            self._conflict_wait_events += 1
                        self._blocked_since.setdefault(agv.agv_id, step)
                        continue
                    agv.cur_node = dst
                    # Note: do **not** release the arrival claim here.
                    # Later vehicles within the same step still rely on it to see "this
                    # node is already taken"; otherwise three vehicles cram into a
                    # capacity-2 aisle node. Releasing is left to ``_refresh_node_holds``
                    # on the next step, which also converts it into a dwell reservation.
                    del self._transit[agv.agv_id]
                continue

            job = self._jobs.get(agv.agv_id)
            if job is None:
                agv.idle_steps += 1
                agv.state = AgvState.IDLE
                continue

            # 1.5) Park task: it ends once the route is finished and involves no task
            if job.leg == "park" and job.idx >= len(job.hops):
                agv.cur_task = None
                agv.state = AgvState.IDLE
                del self._jobs[agv.agv_id]
                agv.idle_steps += 1
                continue

            # 2) Loading dwell after reaching the pickup point
            load_end = self._load_end.get(agv.agv_id, 0)
            if job.leg == "to_pickup" and job.idx >= len(job.hops) and step < load_end:
                # The vehicle is already standing at the pickup point and loading has
                # begun: from this moment the load counts as being on board.
                # PICKED must be set here, otherwise the task stays ASSIGNED during
                # this period and ``_break_deadlock`` returns it to PENDING — but the
                # load has in fact been moved onto the vehicle, and the next vehicle
                # going to the pickup point finds nothing.
                task = self._task_by_id[job.task_id]
                if task.status is TaskStatus.ASSIGNED:
                    task.status = TaskStatus.PICKED
                    task.pickup_step = step
                agv.busy_steps += 1
                agv.state = AgvState.LOADING
                continue
            if job.leg == "to_pickup" and job.idx >= len(job.hops) and step >= load_end:
                task = self._task_by_id[job.task_id]
                # Plan the second leg on the spot: reserve only now, to avoid locking
                # the drop-off area ahead of time
                leg2 = self._plan_and_reserve(
                    agv, task.pickup, task.dropoff, step,
                    getattr(self.planner, "reservations_aware", False),
                )
                if leg2 is None:
                    # The second leg cannot be planned: the vehicle can only stand at
                    # the pickup point and wait.
                    #
                    # This **must count toward the blocking timer**, otherwise it
                    # forms a real livelock: the vehicle occupies the workstation for a
                    # long time in the LOADING state, never enters _blocked_since, so
                    # _break_deadlock never sees it and the task is never delivered.
                    #
                    # Measured on the grid layout with 50 tasks / 6 vehicles / seed 0:
                    # four tasks all had B3 as their pickup point, B3 has capacity 2,
                    # two vehicles each sat on B3 failing to replan again and again, the
                    # other two tasks could never get a slot, completions froze at 46/50,
                    # the simulation idled on to max_steps (120k steps), and the whole
                    # script hung for 50 minutes.
                    agv.busy_steps += 1
                    agv.state = AgvState.LOADING
                    agv.blocked_steps += 1
                    if agv.agv_id not in self._blocked_since:
                        self._blocked_since[agv.agv_id] = step
                    continue
                hops2, t_drop, upto2 = leg2
                if getattr(self.planner, "reservations_aware", False):
                    self._res.reserve_node(
                        task.dropoff, Interval(t_drop, t_drop + self._unload_steps(task)), agv.agv_id
                    )
                job.hops = hops2
                job.idx = 0
                job.goal = task.dropoff
                job.leg = "to_dropoff"
                job.reserved_upto = upto2
                self._drop_end[agv.agv_id] = t_drop + self._unload_steps(task)
                task.status = TaskStatus.PICKED
                task.pickup_step = step
                agv.state = AgvState.TO_DROPOFF

            # 3) Unloading dwell after reaching the drop-off point
            if job.leg == "to_dropoff" and job.idx >= len(job.hops):
                drop_end = self._drop_end.get(agv.agv_id, 0)
                if step < drop_end:
                    agv.busy_steps += 1
                    agv.state = AgvState.UNLOADING
                    continue
                task = self._task_by_id[job.task_id]
                task.status = TaskStatus.COMPLETED
                task.complete_step = drop_end
                # Workstation processing: after unloading, the workstation is still
                # occupied by the workpiece for process_time.
                # The AGV does not wait along — it leaves once unloaded, and the
                # occupancy is borne by the workstation itself.
                psteps = self._process_steps()
                if psteps > 0 and self._has_processing(task.dropoff):
                    self._process_holds.setdefault(task.dropoff, []).append(
                        (drop_end, drop_end + psteps, agv.agv_id))
                agv.cur_task = None
                agv.state = AgvState.IDLE
                del self._jobs[agv.agv_id]
                for d in (self._load_end, self._drop_arrive, self._drop_end):
                    d.pop(agv.agv_id, None)
                agv.busy_steps += 1
                continue

            # 4) Take the next hop along the plan
            if job.idx >= len(job.hops):
                agv.idle_steps += 1
                continue
            self._extend_reservations(agv, job, step)
            hop = job.hops[job.idx]
            src = agv.cur_node or agv.start_node
            if src != hop.src:
                # The actual position does not match the first planned hop — this is a
                # **genuine fault** and is counted separately.
                self._hard_failures += 1
                self._task_by_id[job.task_id].status = TaskStatus.FAILED
                agv.cur_task = None
                agv.state = AgvState.IDLE
                del self._jobs[agv.agv_id]
                continue
            # Dwell time at the destination node: the final station loads/unloads,
            # intermediate stations stop for only 1 step
            is_final = job.idx == len(job.hops) - 1
            if is_final and job.leg == "to_pickup":
                dwell = self._load_steps()
            elif is_final and job.leg == "to_dropoff":
                dwell = self._unload_steps()
            else:
                dwell = 1

            if self._can_enter(agv, hop.src, hop.dst, step, dwell):
                # Early departure: migrate this hop's original reservations to the
                # actual instants, so a phantom time window is not held any longer
                if step != hop.depart:
                    self._res.release_edge(
                        hop.src, hop.dst, Interval(hop.depart, hop.arrive), agv.agv_id
                    )
                    if self.network.has_edge(hop.dst, hop.src):
                        self._res.release_edge(
                            hop.dst, hop.src, Interval(hop.depart, hop.arrive), agv.agv_id
                        )
                    self._res.release_node(
                        hop.dst, Interval(hop.arrive, hop.arrive + 1), agv.agv_id
                    )
                    hop.depart = step
                    hop.arrive = step + self._hop_steps(hop.src, hop.dst)
                    self._reserve_hop(agv, hop)
                self._commit_move(agv, hop.src, hop.dst, step, dwell)
                job.idx += 1
                agv.busy_steps += 1
                self._blocked_since.pop(agv.agv_id, None)
                agv.state = AgvState.TO_PICKUP if job.leg == "to_pickup" else AgvState.TO_DROPOFF
            else:
                self._blocked += 1
                agv.blocked_steps += 1
                agv.busy_steps += 1
                agv.state = AgvState.BLOCKED
                if agv.agv_id not in self._blocked_since:
                    self._conflict_wait_events += 1
                self._blocked_since.setdefault(agv.agv_id, step)

    def _record(self, step: int) -> None:
        if not self.config.record_trajectory:
            return
        pos: dict[str, str] = {}
        states: dict[str, str] = {}
        jobs: dict[str, str | None] = {}
        paths: dict[str, list[str]] = {}
        n_blocked = 0
        for a in self.agvs:
            tr = self._transit.get(a.agv_id)
            pos[a.agv_id] = f"{tr[0]}->{tr[1]}" if tr else (a.cur_node or "")
            states[a.agv_id] = a.state.value
            job = self._jobs.get(a.agv_id)
            jobs[a.agv_id] = job.task_id if job is not None else None
            # Remaining path = the sequence of hop destinations not yet covered by the
            # current leg.
            #
            # Note the semantics of idx: _Job.idx points at "the hop currently being
            # travelled".
            # The remaining path must therefore include the destination of the hop at
            # idx, otherwise the drawn line falls one segment short of what the vehicle
            # actually has to travel (this off-by-one only shows up when drawing).
            if job is not None and job.hops:
                rest = [h.dst for h in job.hops[job.idx:]]
                if rest:
                    paths[a.agv_id] = rest
            if a.state is AgvState.BLOCKED:
                n_blocked += 1
        counts = {"pending": 0, "assigned": 0, "picked": 0, "completed": 0}
        for task in self._task_by_id.values():
            key = task.status.value
            if key in counts:
                counts[key] += 1
        holds: dict[str, list[str]] = {}
        for node, items in self._res.snapshot(step, step + 1).items():
            holds[node] = [owner for _, _, owner in items]
        self._trajectory.append(
            StepRecord(
                step=step,
                agv_positions=pos,
                agv_states=states,
                agv_tasks=jobs,
                task_counts=counts,
                n_blocked=n_blocked,
                node_holds=holds,
                agv_paths=paths,
                preemptions=list(self._step_preemptions),
            )
        )
        self._step_preemptions.clear()
