"""The data interface: turns the scheduler's output into a format both the visualiser
and a real vehicle can consume.

Why a separate layer
--------------------
Before this existed, the Python scheduling core (``amr_sched``) produced Python objects
and the C# RAWSim-O adapter read its own data model,

with **no interface** between the two.

The result was two separate software artefacts: the simulation ran and the interface
animated, but they had nothing to do with each other.


This layer defines a **stable, language-neutral** exchange format:


    Simulator ──► FrameStream ──► JSON ──► visualiser / RAWSim-O / vehicle monitor

Three design constraints
--------------
**1. A pose must carry its provenance.**
Simulation truth, integrated odometry, and map localisation are three kinds of data with
entirely different accuracy,

and mixing them makes "does the real vehicle agree with the simulation" impossible to
discuss.
:class:`Pose` therefore always carries a :class:`PoseSource`, defaulting to ``SIM``;
the real-vehicle side must declare ``ODOM`` or ``LOCALIZED`` explicitly.

**2. A frame is self-contained.**
Any single frame can be read without its neighbours: who is where, what they are doing,
what state each task is in.
A monitor can then join at any moment, skip frames, or replay without starting from the
beginning.

**3. The format is versioned.**
``SCHEMA_VERSION`` is exported so a consumer can refuse an incompatible stream.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Iterable

from .simulation import SimulationResult, StepRecord

#: Exchange format version. Any incompatible change must bump it, and consumers should
#: refuse a mismatch.
SCHEMA_VERSION = "1.0"


class PoseSource(str, Enum):
    """Pose provenance. **Never mix these**, and in particular never present ODOM as an
    absolute position."""

    #: The simulator's own truth: no noise, no drift. Used for algorithm comparison and
    #: experiment statistics.
    SIM = "sim"
    #: Pose estimated by integrating wheel speed and IMU. It **drifts**, so it is fit only
    #: for drawing a track.
    ODOM = "odom"
    #: Pose after map matching or loop closure. Used to assess real-vehicle localisation
    #: accuracy.
    LOCALIZED = "localized"


@dataclass
class Pose:
    """Where one vehicle is at one moment.

At least one of ``node`` and ``edge`` is set:

- on a node: ``node`` holds its id;
- in transit: ``edge`` is ``"A->B"`` and ``progress`` is the fraction travelled, 0..1.
    """

    agv_id: str
    node: str | None = None
    edge: str | None = None
    progress: float = 0.0
    source: PoseSource = PoseSource.SIM
    #: Filled with a CAN timestamp on a real vehicle; left empty in simulation.
    timestamp: float | None = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["source"] = self.source.value
        return d


@dataclass
class AgvFrame:
    """One vehicle's complete state within a frame."""

    agv_id: str
    pose: Pose
    #: idle / to_pickup / loading / to_dropoff / unloading / blocked / parking
    state: str
    task_id: str | None = None
    #: Remaining node sequence for this leg, including the goal. Used to draw the path.
    #: An empty list when unavailable -- do **not** infer from that that the vehicle is
    #: standing still.
    path: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialise to the per-vehicle mapping inside a frame.

        Added in round 65: this used to be written out by hand inside
        ``Frame.to_dict()`` only, and reusing it from the live channel
        (``FrameBuilder``) is what revealed that ``AgvFrame`` had no matching method.
        Adding it and making ``Frame.to_dict()`` call it keeps the offline export and
        the live push **field-for-field identical**.
        """
        return {
            "agv_id": self.agv_id,
            "pose": self.pose.to_dict(),
            "state": self.state,
            "task_id": self.task_id,
            "path": list(self.path),
        }


@dataclass
class Frame:
    """A complete, **self-contained** snapshot of one time step."""

    step: int
    t: float
    agvs: list[AgvFrame] = field(default_factory=list)
    #: Task counts by state: pending / assigned / picked / completed
    task_counts: dict[str, int] = field(default_factory=dict)
    #: How many vehicles are blocked this step
    n_blocked: int = 0
    #: Preemption events this step: [{urgent, victim_agv, victim_task, was_picked}]
    preemptions: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": "frame",
            "schema": SCHEMA_VERSION,
            "step": self.step,
            "t": round(self.t, 3),
            "agvs": [a.to_dict() for a in self.agvs],
            "task_counts": dict(self.task_counts),
            "n_blocked": self.n_blocked,
            "preemptions": list(self.preemptions),
        }


@dataclass
class NetworkSpec:
    """Network topology, so a consumer can draw the base map without rebuilding it."""

    nodes: list[dict[str, Any]] = field(default_factory=list)
    edges: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_network(cls, net: Any) -> "NetworkSpec":
        nodes = [
            {
                "id": n.node_id,
                "kind": n.kind.value,
                "capacity": n.capacity,
                "x": getattr(n, "x", None),
                "y": getattr(n, "y", None),
            }
            for n in net.nodes.values()
        ]
        # ``Network.edges`` returns a dict keyed by (src, dst) whose values are
        # Edge objects -- iterating the dict alone yields only the keys, which is
        # how the edge length used to end up as a constant None on the wire.
        # Read the values instead and publish the length under both names so early
        # consumers (``u``/``v``/``w``) and the C# side (``src``/``dst``/``length``)
        # keep working.
        edges = []
        for (u, v), edge in net.edges.items():
            edges.append({
                "u": u, "v": v, "w": edge.length,
                "src": u, "dst": v, "length": edge.length,
                "capacity": edge.capacity,
            })
        return cls(nodes=nodes, edges=edges)


def _split_edge(pos: str, progress: float = 0.0) -> tuple[str | None, str | None, float]:
    """Split an "A->B" or "A" position into (node, edge, progress).

    ``progress`` must be supplied by the caller: the position string alone only
    says *which* edge the vehicle is on, never how far along it. It used to
    default to 0.0 here, which made every in-transit pose look like the vehicle
    was sitting exactly on the source node.
    """
    if "->" in pos:
        u, v = pos.split("->", 1)
        return None, f"{u}->{v}", float(progress)
    return (pos or None), None, 0.0


def frames_from_result(
    result: SimulationResult,
    *,
    dt: float = 1.0,
    stride: int = 1,
    source: PoseSource = PoseSource.SIM,
) -> list[Frame]:
    """Turn a :class:`SimulationResult` trajectory into a sequence of :class:`Frame`.

    Args:
        stride: frame interval. 1 means one frame per step, 10 means one per ten steps.
            Replay usually uses 5..20, trading file size against smoothness.
        source: pose provenance. Simulation results should keep the ``SIM`` default.
    """
    frames: list[Frame] = [];
    for rec in result.trajectory:
        if rec.step % stride:
            continue;
        frames.append(_frame_from_record(rec, dt=dt, source=source))
    return frames


def _frame_from_record(
    rec: StepRecord, *, dt: float, source: PoseSource
) -> Frame:
    agvs: list[AgvFrame] = [];
    for agv_id, pos in rec.agv_positions.items():
        node, edge, progress = _split_edge(pos)
        agvs.append(
            AgvFrame(
                agv_id=agv_id,
                pose=Pose(
                    agv_id=agv_id, node=node, edge=edge,
                    progress=progress, source=source,
                ),
                state=rec.agv_states.get(agv_id, "idle"),
                task_id=rec.agv_tasks.get(agv_id),
                path=list(rec.agv_paths.get(agv_id, [])),
            )
        )
    pre = [
        {"urgent": p[0], "victim_agv": p[1],
         "victim_task": p[2], "was_picked": bool(p[3])}
        for p in rec.preemptions
    ]
    return Frame(
        step=rec.step,
        t=rec.step * dt,
        agvs=agvs,
        task_counts=dict(rec.task_counts),
        n_blocked=rec.n_blocked,
        preemptions=pre,
    )


def export_stream(
    result: SimulationResult,
    path: str,
    *,
    dt: float = 1.0,
    stride: int = 1,
    network: Any | None = None,
    meta: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Export to a single JSON file for the visualiser, the RAWSim-O adapter, or a
    real-vehicle monitor.

    File structure::

        {
          "schema": "1.0",
          "meta": {...},          // 场景与实验标识
          "network": {...},       // 拓扑，画底图用
          "frames": [...]         // 逐帧状态
        }

Returns a summary (frame count, byte count, and so on) so the caller can record it.
    """
    frames = frames_from_result(result, dt=dt, stride=stride)
    if not frames:
        raise ValueError(
            "there are no frames at all. The most common cause is "
            "record_trajectory=False in SimulationConfig, the memory-saving default."
            "Turn it on explicitly before exporting: "
            "SimulationConfig(record_trajectory=True)."
        )
    payload: dict[str, Any] = {
        "schema": SCHEMA_VERSION,
        "meta": {
            "dt": dt,
            "stride": stride,
            "n_frames": len(frames),
            "finished_step": result.finished_step,
            **(meta or {}),
        },
        "network": (
            asdict(NetworkSpec.from_network(network)) if network is not None else None
        ),
        "frames": [f.to_dict() for f in frames],
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
    import os
    return {
        "path": path,
        "n_frames": len(frames),
        "bytes": os.path.getsize(path),
        "schema": SCHEMA_VERSION,
    }


# ---------------------------------------------------------------------------
# Live channel (added in round 65)
# ---------------------------------------------------------------------------
#
# Before this the C# side could only call `StreamDocument.Load(path)` on a finished JSON
# file, that is, read results offline. What the supervisor asked for -- a marker on the
# map that follows the vehicle -- needs **pushing while the run is going**.
#
# The exchange format is unchanged (schema is still 1.0); the same Frame is simply pushed
# frame by frame. The transport is **newline-delimited JSON over TCP**:
#   * the C# side needs no WebSocket library, just one StreamReader.ReadLine per line;
#   * it can be inspected by eye with `nc` or `telnet`;
#   * reconnection realigns naturally: discard the partial line and resynchronise on the
#
# next one. Contract: once a connection is up the server sends one `hello` line
# (schema, network, meta), then one `frame` line per frame. A client only parses lines;
# there is **no handshake**.


class FrameBuilder:
    """Build Frames straight from a **running Simulator**, without a SimulationResult.

    Why not call ``frames_from_result`` afterwards: that needs `record_trajectory`
    to accumulate the whole trajectory in memory, which in a live setting both wastes
    memory and still cannot give you *now*. Reading the simulator's current state gives
    the actual current frame.
    """

    def __init__(self, sim: Any, source: PoseSource = PoseSource.SIM) -> None:
        self.sim = sim
        self.source = source
        self.network = sim.network

    def hello(self) -> dict[str, Any]:
        """The first message on connect: network plus metadata."""
        spec = NetworkSpec.from_network(self.network)
        return {
            "type": "hello",
            "schema": SCHEMA_VERSION,
            "source": self.source.value,
            "network": {"nodes": spec.nodes, "edges": spec.edges},
            "meta": {
                "n_tasks": len(self.sim.tasks),
                "n_agvs": len(self.sim.agvs),
                "dt": self.sim.config.dt,
                "agv_ids": [a.agv_id for a in self.sim.agvs],
            },
        }

    def frame(self) -> dict[str, Any]:
        """The complete frame for the current step, field-compatible with the offline format."""
        sim = self.sim
        dt = sim.config.dt
        step = sim._step_cursor
        agvs = []
        n_blocked = 0
        for a in sim.agvs:
            tr = sim._transit.get(a.agv_id)
            progress = 0.0
            if tr:
                pos = "%s->%s" % (tr[0], tr[1])
                # _transit is (src, dst, depart, arrive); interpolate between the
                # two so the pose reflects how far the vehicle actually got.
                depart, arrive = int(tr[2]), int(tr[3])
                span = max(1, arrive - depart)
                progress = min(1.0, max(0.0, (step - depart) / span))
            else:
                pos = a.cur_node or ""
            node, edge, prog = _split_edge(pos, progress)
            pose = Pose(agv_id=a.agv_id, node=node, edge=edge,
                        progress=prog, source=self.source,
                        timestamp=step * dt)
            job = sim._jobs.get(a.agv_id)
            rest: list[str] = []
            if job is not None and job.hops:
                rest = [h.dst for h in job.hops[job.idx:]]
            agvs.append(AgvFrame(
                agv_id=a.agv_id, pose=pose, state=a.state.value,
                task_id=job.task_id if job is not None else None,
                path=rest,
            ).to_dict())
            if a.state.value == "blocked":
                n_blocked += 1
        counts: dict[str, int] = {}
        for t in sim.tasks:
            counts[t.status.value] = counts.get(t.status.value, 0) + 1
        return {
            "type": "frame",
            "schema": SCHEMA_VERSION,
            "step": step,
            "t": round(step * dt, 3),
            "agvs": agvs,
            "task_counts": counts,
            "n_blocked": n_blocked,
            "preemptions": [
                {"urgent": u, "victim_agv": va, "victim_task": vt,
                 "was_picked": bool(wp)}
                for (u, va, vt, wp) in getattr(sim, "_step_preemptions", [])
            ],
        }


def frame_to_line(obj: dict[str, Any]) -> bytes:
    """Encode one message as a line of UTF-8 JSON, including the newline."""
    return (json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
